This is a package for testing eggs in `PyInstaller`_

:Author:    Hartmut Goebel <h.goebel@goebel-consult.de>
:Copyright: 2012-2021, PyInstaller Development Team.
:Licence:   GNU Public Licence v3 (GPLv3)

_PyInstaller: www.pyinstaller.org
